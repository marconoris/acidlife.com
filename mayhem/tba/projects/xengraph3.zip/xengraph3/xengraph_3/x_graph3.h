/*
 *
 * $Id: x_bmp3.h,v 1.0 18/05/01 *:*:* xenion Exp $
 *
 * ---------------------------------------------------------------------------
 * No part of this project may be used to break the law, or to cause damage of
 * any kind. And I'm not responsible for anything you do with it.
 * ---------------------------------------------------------------------------
 * "THE BEER-WARE LICENSE" (by Poul-Henning Kamp, Revision 42):
 * <xenion@acidlife.com> wrote this file.  As long as you retain this notice
 * you can do whatever you want with this stuff. If we meet some day, and you
 * think this stuff is worth it, you can buy me a beer in return.
 * xenion ~ Dallachiesa Michele
 * ---------------------------------------------------------------------------
 */


/*

* non testato al 100% *

library for 13h graphic mode.

*/


#include <stdio.h>
#include <dos.h>
#include <stdlib.h>
#define MCGA 0x13
#define TEXT 0x2

/*
scambia palette pal1 con pal2
*/
void inv_pal(char *pal1, char *pal2, int start_color, int end_color) {
 char mom;
 int d;

 for(d=start_color*3;d<(end_color+1)*3;d++) {
  mom=pal1[d];
  pal1[d]=pal2[d];
  pal2[d]=mom;
  }
}

/*
carica palette da file
*/
int fopen_pal(char *filename, char *pal, int start_color, int end_color) {
 FILE *in;
 int d=start_color*3;

 if((in= fopen(filename,"rb"))== NULL)
  return(NULL);

 while (!feof(in)) {
  pal[d++]=fgetc(in);
  if(d>(end_color+1)*3)
   break;
  }

 fclose(in);
 return(1);
}


/*
carica palette
*/
void open_pal( char *pal) {
 int d,i;

 outportb(0x3c8,0);
 for(d=0,i=0;d<256;d++,i+=3) {
   outportb(0x3c9,pal[i+0]);
   outportb(0x3c9,pal[i+1]);
   outportb(0x3c9,pal[i+2]);
   }
}


/*
visualizza 1 pixel alle coordinate P(x,i) con colore (color)
*/
void putpixel(unsigned x, unsigned y, char color) {
 unsigned k=y*320+x;

 asm {
  mov ax, 0a000h
  mov es, ax
  mov si, k
  mov al, color
  mov es:[si], al
  }
}

/*
visualizza 1 pixel ad un certo offset con colore (color)
*/
void put_off(unsigned offset, unsigned char color) {
unsigned k=offset;

 asm {
  mov ax, 0a000h
  mov es, ax
  mov si, k
  mov al, color
  mov es:[si], al
  }
}

/*
prendi colore pixel alle coordinate P(x,i)
*/
int getpixel(unsigned x, unsigned y) {
 unsigned k=y*320+x;
 char color;

 asm {
  mov ax, 0a000h
  mov es, ax
  mov si, k
  mov al, byte ptr es:[si]
  mov color, al
  }
 return color;
}


/*
setta la modalita' video
*/
void set_vmode(char mode) {
 asm {
  mov ah, 0
  mov al, mode
  int 10h
  }
 }

/*
decrementa i valori RGB di tutti i colori presenti nella palette fino a 0.
quando tutti i colori della palette hanno R=G=B=0 la funzione torna 0.
*/
int dec_pal(char *pal, int start_color, int end_color) {
 int d,eh=0;

 for(d=start_color*3;d<(end_color+1)*3;d++)
  if(pal[d]>0) {
   pal[d]--;
   eh++;
   }
 return(eh);
}

/*
incrementa i valori RGB di tutti i colori presenti nella palette fino a 63.
quando tutti i colori della palette hanno R=G=B=63 la funzione torna 0.
*/
int inc_pal(char *pal, int start_color, int end_color) {
 int d,eh=0;

 for(d=start_color*3;d<(end_color+1)*3;d++)
  if(pal[d]<63) {
   pal[d]++;
   eh++;
   }
 return(eh);
}

/*
ruota di 1 colore la palette
*/
void rot_pal(char *pal, int start_color, int end_color) {
 char temp[3];
 int d;

 temp[0]=pal[start_color*3+0];
 temp[1]=pal[start_color*3+1];
 temp[2]=pal[start_color*3+2];
 for(d=start_color*3;d<((end_color+1)*3-5);d+=3) {
  pal[d+0]=pal[d+3];
  pal[d+1]=pal[d+4];
  pal[d+2]=pal[d+5];
  }
 pal[end_color*3+0 ]=temp[0];
 pal[end_color*3+1 ]=temp[1];
 pal[end_color*3+2 ]=temp[2];
}


/*
avvicina i valori RGB dei colori di pal2 a quelli di pal1.
quando pal2 e' uguale a pal1 la funzione torna 0.
*/
int morph_pal(char *pal1, char *pal2, int start_color, int end_color) {
int d,he=0;

 for(d=start_color*3;d<(end_color+1)*3;d++) {
  if(pal1[d]>pal2[d]) {
   pal2[d]++;
   he++;
   }
  if(pal1[d]<pal2[d]) {
   pal2[d]--;
   he++;
   }
  }
 return(he);
}



