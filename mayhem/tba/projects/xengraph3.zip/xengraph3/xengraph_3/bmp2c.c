/*
 *
 * $Id: bmp2c.c,v 1.0 13/06/01 *:*:* xenion Exp $
 *
 * ---------------------------------------------------------------------------
 * No part of this project may be used to break the law, or to cause damage of
 * any kind. And I'm not responsible for anything you do with it.
 * ---------------------------------------------------------------------------
 * "THE BEER-WARE LICENSE" (by Poul-Henning Kamp, Revision 42):
 * <xenion@acidlife.com> wrote this file.  As long as you retain this notice
 * you can do whatever you want with this stuff. If we meet some day, and you
 * think this stuff is worth it, you can buy me a beer in return.
 * xenion ~ Dallachiesa Michele
 * ---------------------------------------------------------------------------
 */

/*


* non testato al 100% *

bmp2c v1.0
 salva la palette e l'immagine di un file .bmp(320*200*256) in un file
 di testo utilizzabile all'interno di programmi C
 usage: bmp2c input.bmp image.h



 esempio: si vuole creare un' eseguibile che visualizzi il file cht.bmp :

  $bmp2c a.bmp a.h
  $type view.c

  #include "x_graph3.h"
  #include "a.h"

  unsigned char *VGA=(unsigned char *)0xA0000000L;
  unsigned i;

  int main() {
   set_vmode(MCGA);
   open_pal(palette);
   for(i=0;i<64000;i++)
    *(VGA+i)=image[i];
  }

*/

#include <stdio.h>
#include <stdlib.h>
#include "x_graph3.h"
#include "x_bmp3.h"

void help() {
printf("bmp2c@xen_graphics utility\n\n");
printf(" salva la palette e l'immagine di un file .bmp(320*200*256) in un file\n");
printf(" di testo utilizzabile all'interno di programmi C\n");
printf(" usage: bmp2c input.bmp image.h\n\n");
exit(-1);
}

int main(int argc, char **argv) {
 FILE *out;
 unsigned i,t;
 BITMAP_HEADER bmp_header;
 BITMAP_DATA bmp_data;

 if(argc<2)
  help();

 load_bmp(argv[1], &bmp_header, &bmp_data);
 if(HEIGHT!=200 || WIDTH!=320 || bmp_header.info_header.biClrUsed!=256)
  err("image must be 320*200*256");

 if((out=fopen(argv[2],"wb")) == NULL)
  err("unable to open output file");

 fprintf(out,"char palette[]={\n");
 for(i=0;i<256*3;i+=12) {
  for(t=0;t<12;t++) {
    fprintf(out, "%d",(unsigned char)*(bmp_data.palette+i+t));
    fprintf(out, ",");
    }
  fprintf(out, "\n");
  }

 fprintf(out,"0 };\n\n\n");  // lo 0 e' inutile ma semplifica il programma.. :)

 fprintf(out,"char image[]={\n");
 for(i=0;i<64000;i+=20) {
  for(t=0;t<20;t++) {
    fprintf(out, "%d",(unsigned char)*(bmp_data.image+i+t));
    fprintf(out, ",");
    }
  fprintf(out, "\n");
  }
 fprintf(out,"0 };\n"); // lo 0 e' inutile ma semplifica il programma.. :)

 return(0);
}
