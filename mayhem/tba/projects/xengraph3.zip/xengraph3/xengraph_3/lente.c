/*
 *
 * $Id: lente.c,v 1.0 14/08/01 *:*:* xenion Exp $
 *
 * ---------------------------------------------------------------------------
 * No part of this project may be used to break the law, or to cause damage of
 * any kind. And I'm not responsible for anything you do with it.
 * ---------------------------------------------------------------------------
 * "THE BEER-WARE LICENSE" (by Poul-Henning Kamp, Revision 42):
 * <xenion@acidlife.com> wrote this file.  As long as you retain this notice
 * you can do whatever you want with this stuff. If we meet some day, and you
 * think this stuff is worth it, you can buy me a beer in return.
 * xenion ~ Dallachiesa Michele
 * ---------------------------------------------------------------------------
 */


/*

* non testato al 100% *


author :  xenion(99%) & Derte(1%)

 lente di ingrandimento


* funziona principalmente con il mouse.. e' possibile aumentare o diminuire la zona da ingrandire
  e spostarsi nell'immagine. (per uscire premere un tasto)

*/

#include <stdio.h>
#include "x_graph3.h"
#include "x_bmp3.h"

#define ING 1
#define L_DEF 30
#define FAT_DEF 2

/*
Checks for currently available keystrokes.
If a keystroke is available, kb_hit returns 1 value. Otherwise, it returns 0.
*/
int kb_hit(void) {
 char what=0;

 asm {
   push ax
   mov ah, 1
   int 16h
   je no
   mov what, 1
   no:
   pop ax
   }

 return what;
}


/*
salva in x e y le coordinate del mouse e torna lo stato del mouse.
0 == nessun tasto premuto
1 == SX premuto
2 == DX premuto
4 == middleX premuto
*/
void mouse_stat(int *x, int *y, int *stat) {
int x_, y_, stat_;

 asm {
   push ax
   push bx
   push cx
   push dx
   mov  ax,3
   mov bx, 0
   int  33h
   mov x_, cx
   mov y_, dx
   mov stat_, bx
   pop dx
   pop cx
   pop bx
   pop ax
   }

 *x=x_;
 *y=y_;
 *stat= stat_;
 }


/*
setta limiti del mouse.
x= xmin
x2=xmax
y=ymin
y2=ymax
*/
void mouse_lim(int x, int x2, int y, int y2) {

 asm {
   push ax
   push cx
   push dx
   mov cx, x
   mov dx, x2
   mov ax, 7
   int 33h
   mov cx, y
   mov dx, y2
   mov ax, 8
   int 33h
   pop dx
   pop cx
   pop ax
   }
}

/*
disegna quadrato di lato l dal punto P(wherex, wherey) con colore color
*/
void square(int wherex, int wherey, int l, int color) {
 int x, y;

 for(x=wherex;x<wherex+l; x++)
  for(y=wherey;y<wherey+l; y++)
   putpixel(x,y,color);
}


void lente(BITMAP_HEADER bmp_header, BITMAP_DATA bmp_data, int wherex, int wherey, int l, int fat) {
 int x,y;
 char *quad;

 quad= region_bmp(bmp_header, bmp_data, wherex, wherey, l, l);

 for(x=0;x<l;x++)
  for(y=0;y<l;y++)
   square(wherex+x*fat, wherey+y*fat, fat, *(quad+l*y+x));

 free(quad);
}

/*
disegna un frame quadrato di lato l dal punto P(wherex, wherey) con colore color
*/
void frame(int wherex, int wherey, int l, char color) {
 int x, y;

 for(x=wherex;x<wherex+l+1;x++) {
  putpixel(x, wherey, color);
  putpixel(x, wherey+l, color);
  }
 for(y=wherey;y<wherey+l;y++) {
  putpixel(wherex, y, color);
  putpixel(wherex+l, y, color);
  }
}

/*
aspetta un cambiamento nello stato del mouse o della tastiera
*/
void delay_mouse(int *xx, int *yy, int *sstat) {
 int x, x_, y, y_, stat, stat_;

 mouse_stat(&x, &y, &stat);

 do
  mouse_stat(&x_, &y_, &stat_);
 while(x==x_ && y==y_ && stat==stat_ && !kb_hit());

 *xx=x_;
 *yy=y_;
 *sstat= stat_;
}


void help() {
 printf("lente by xenion\n");
 printf("usage: lente file.bmp   (the BMP file must be in 256x256x256 format)\n\n");
 exit(0);
 }

int main(int argc, char **argv) {
 BITMAP_HEADER bmp_header;
 BITMAP_DATA bmp_data;
 char *restore, pal[768];
 int x, y, x_, y_, stat, l=L_DEF, fat=FAT_DEF;

 if(argc<2)
  help();

 for(x=0;x<768;x++)
  pal[x]=0;

 load_bmp(argv[1], &bmp_header, &bmp_data);

 if(WIDTH>320 || HEIGHT> 200) {
  free(bmp_data.image);
  free(bmp_data.palette);
  err("the BMP file must be in 256x256x256 format");
  }

 set_vmode(MCGA);

 open_pal(pal);
 view_bmp(bmp_header, bmp_data.image, 0, 0);
 delay_mouse(&x, &y, &stat);

 do {
  mouse_lim(0,(int)WIDTH-l*fat,0,(int)HEIGHT-l*fat);
  restore= region_bmp(bmp_header, bmp_data, x, y, l*fat, l*fat);
  lente(bmp_header, bmp_data, x_=x, y_=y, l, fat);
  frame(x, y, fat*l-1, 0);
  delay_mouse(&x, &y, &stat);
  morph_pal(bmp_data.palette, pal, 0, 256);
  open_pal(pal);
  view_region(restore, x_, y_, l*fat, l*fat);
  free(restore);

  if(stat==1 && HEIGHT>y+(l+ING)*fat && WIDTH>x+(l+ING)*fat)
   l+=ING;
  else
   if(stat==2 && l>ING)
    l-=ING;

  } while(!kb_hit());

 free(bmp_data.image);
 free(bmp_data.palette);

 set_vmode(TEXT);

 return 0;
}
