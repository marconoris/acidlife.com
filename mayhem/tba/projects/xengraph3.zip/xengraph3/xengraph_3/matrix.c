/*
 *
 * $Id: matrix.c,v 1.0 25/05/01 *:*:* xenion Exp $
 *
 * ---------------------------------------------------------------------------
 * No part of this project may be used to break the law, or to cause damage of
 * any kind. And I'm not responsible for anything you do with it.
 * ---------------------------------------------------------------------------
 * "THE BEER-WARE LICENSE" (by Poul-Henning Kamp, Revision 42):
 * <xenion@acidlife.com> wrote this file.  As long as you retain this notice
 * you can do whatever you want with this stuff. If we meet some day, and you
 * think this stuff is worth it, you can buy me a beer in return.
 * xenion ~ Dallachiesa Michele
 * ---------------------------------------------------------------------------
 */


/*

* non testato al 100% *


matrix.c

 esempio di utilizzo della x_graph3.h

*/

#include <stdio.h>
#include <stdlib.h>
#include "x_graph3.h"


int main() {
 char pal[256*3];
 int a,i,d;

 pal[0]=pal[1]=pal[2]=0;

 if(fopen_pal("blu.pal", pal, 1,255)== NULL) {
  printf("unable to open palette!\n");
  return(0);
  }

 set_vmode(MCGA);
 open_pal(pal);

 for(a=0;1;a++)
  for(i=0;i<320;i++)
   for(d=0;d<200;d++)
    putpixel(i,d,getpixel(d+i-a,d-i)+1);

 set_vmode(TEXT);
 return(0);
}



