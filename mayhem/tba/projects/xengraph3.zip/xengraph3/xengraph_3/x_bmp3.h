/*
 *
 * $Id: x_bmp3.h,v 1.0 18/05/01 *:*:* xenion Exp $
 *
 * ---------------------------------------------------------------------------
 * No part of this project may be used to break the law, or to cause damage of
 * any kind. And I'm not responsible for anything you do with it.
 * ---------------------------------------------------------------------------
 * "THE BEER-WARE LICENSE" (by Poul-Henning Kamp, Revision 42):
 * <xenion@acidlife.com> wrote this file.  As long as you retain this notice
 * you can do whatever you want with this stuff. If we meet some day, and you
 * think this stuff is worth it, you can buy me a beer in return.
 * xenion ~ Dallachiesa Michele
 * ---------------------------------------------------------------------------
 */



/*

* non testato al 100% *


.bmp library version 3 
* corretti alcuni bug

 
* richiede la libreria x_graph3.h, presente in xen_graphics3.zip


-- STRUTTURA DI UN FILE .BMP --

|----------------|
| file_header    | ~ 40 byte
|----------------|
| bmp_header     | ~ 14 byte
|----------------|
| palette        | variabile
|----------------|
| data           | variabile
|----------------|
*/

#include <stdio.h>
#include <stdlib.h>
#include <mem.h>
#define BI_RGB      0L
#define BI_RLE8     1L
#define BI_RLE4     2L
#define PHEIGHT     bmp_header->info_header.biHeight
#define PWIDTH      bmp_header->info_header.biWidth
#define HEIGHT      bmp_header.info_header.biHeight
#define WIDTH       bmp_header.info_header.biWidth

typedef unsigned long  DWORD;
typedef unsigned short WORD;
typedef unsigned char  BYTE;

typedef struct tagBITMAPFILEHEADER {
  WORD    bfType;
  DWORD   bfSize;
  WORD    bfReserved1;
  WORD    bfReserved2;
  DWORD   bfOffBits;
} BITMAPFILEHEADER;

typedef struct tagBITMAPINFOHEADER {
   DWORD  biSize;
   DWORD  biWidth;
   DWORD  biHeight;
   WORD   biPlanes;
   WORD   biBitCount;
   DWORD  biCompression;
   DWORD  biSizeImage;
   DWORD  biXPelsPerMeter;
   DWORD  biYPelsPerMeter;
   DWORD  biClrUsed;
   DWORD  biClrImportant;
} BITMAPINFOHEADER;

typedef struct tagBITMAP_HEADER {
  BITMAPFILEHEADER file_header;
  BITMAPINFOHEADER info_header;
} BITMAP_HEADER;

typedef struct tagBITMAP_DATA {
  char *palette;
  char *image;
} BITMAP_DATA;

void err(char *why) {
 printf("error: %s\n",why);
 exit(-1);
 }

/*
estrae tutte le informazioni possibili da un file di tipo .bmp 256colori non compresso
e le salva nelle due strutture di tipo BITMAP_HEADER e BITMAP_DATA.
(lo spazio puntato da bmp_data.palette e bmp_data.image deve essere liberato con free())
*/
void load_bmp(char *filename, BITMAP_HEADER *bmp_header, BITMAP_DATA *bmp_data) {
 FILE *f;
 unsigned x,y,index;

 if((f= fopen(filename,"rb")) == NULL)
  err("load_bmp(): fopen()");

 if(fread(bmp_header, 1, sizeof *bmp_header, f)!=sizeof *bmp_header)
  err("fread(): bmp_header");

 if((bmp_data->palette= (char*)malloc((WORD)bmp_header->info_header.biClrUsed*3)) == NULL)
  err("load_bmp(): palette: malloc()");

 for(index= 0;index<256*3;index+= 3) {
  bmp_data->palette[index+2]= fgetc(f) >>2;
  bmp_data->palette[index+1]= fgetc(f) >>2;
  bmp_data->palette[index+0]= fgetc(f) >>2;
  fgetc(f);
  if(feof(f))
   err("load_bmp(): palette: file danneggiato o non valido");
  }

 if((bmp_data->image= (char*)malloc((WORD)(PWIDTH*PHEIGHT))) == NULL)
  err("load_bmp(): image: malloc()");

 for(y= 0;y<PHEIGHT;y++)
  for(x= 0;x<PWIDTH;x++) {
   bmp_data->image[(WORD)((PHEIGHT-y-1)*PWIDTH+x)]= fgetc(f);
   if(feof(f))
    err("load_bmp(): image: file danneggiato o non valido");
   }

 fclose(f);
 }

/*
visualizza il file bmp precedentemente caricato
con coordinate iniziali sullo schermo P(x0,y0);
*/
void view_bmp(BITMAP_HEADER bmp_header, char *image, unsigned x0, unsigned y0) {
 unsigned x,y;
 for(y= 0;y<HEIGHT;y++)
  for(x= 0;x<WIDTH;x++)
   putpixel(x+x0, y+y0, image[(WORD)(y*WIDTH+x)]);
}

/*
torna un puntatore all'immagine di dimensioni height*width presa a partire dalla posizione P(x0,y0)
dell'immagine precedentemente caricata nelle strutture di tipo BITMAP_HEADER e BITMAP_DATA.
(l'immagine non viene visualizzata, ne viene solo copiata una regione)
(lo spazio puntato da region deve essere liberato con free())
*/
char *region_bmp(BITMAP_HEADER bmp_header, BITMAP_DATA bmp_data, unsigned x0, unsigned y0, unsigned height, unsigned width) {
 unsigned x,y;
 char *region;

 if((region= (char*)malloc(height*width)) == NULL)
  err("region_bmp(): malloc()");

 for(y= 0;y<height;y++)
  for(x= 0;x<width;x++)
   region[y*width+x]= bmp_data.image[(WORD)((y+y0)*WIDTH+(x+x0))];

 return(region);
 }

/*
visualizza l'immagine di dimensioni height*width dal punto P(x0,y0) dello schermo
Region contiene l'immagine.
*/
void view_region(char *region, unsigned x0, unsigned y0, unsigned height, unsigned width) {
 unsigned x,y;

 for(y= 0;y<height;y++)
  for(x= 0;x<width;x++)
   putpixel(x+x0,y+y0,region[y*width+x]);
 }

/*
salva la sola immagine precedentemente caricata nelle strutture di tipo BITMAP_HEADER e BITMAP_DATA
(niente palette, nessuna informazione sulle dimensioni)
*/
void save_imm(char *filename, BITMAP_HEADER bmp_header, BITMAP_DATA bmp_data) {
 FILE *f;

 if((f= fopen(filename,"wb")) == NULL)
  err("save_imm(): fopen()");

 fwrite(bmp_data.image,(WORD)(HEIGHT*WIDTH),1,f);

 fclose(f);
}

/*
salva la sola palette precedentemente caricata nelle strutture di tipo BITMAP_HEADER e BITMAP_DATA.
(niente immagine, nessuna informazione sul numero di colori)
*/
void save_pal(char *filename, BITMAP_HEADER bmp_header, BITMAP_DATA bmp_data) {
 FILE *f;

 if((f= fopen(filename,"wb")) == NULL)
  err("save_pal(): fopen()");

 fwrite(bmp_data.palette,(WORD)bmp_header.info_header.biClrUsed*3,1,f);

 fclose(f);
}

/*
torna un puntatore all'immagine 320*200 contenuta in filename.

(lo spazio puntato da region deve essere liberato con free())

Il supporto per questo formato non'e' completo, infatti none' possibile
utilizzare altre dimensioni se non 320*200, mentre la save_imm salva
qualunque immagine.
*/
char *load_64k(char *filename) {
 FILE *f;
 char *image;

 if((f= fopen(filename,"rb")) == NULL)
  err("load_64k(): fopen()");

 if((image= (char*)malloc((WORD)(320*200))) == NULL)
  err("load_64k(): malloc()");

 fread(image,(WORD)(320*200),1,f);

 fclose(f);

 return(image);
}

/*
torna un puntatore alla palette di 256 colori (RGB) contenuta in filename.

(lo spazio puntato da palette deve essere liberato con free())

Il supporto per questo formato non'e' completo, infatti none' possibile
utilizzare palette con numero diverso di colori di 256.
*/
char *load_768(char *filename) {
FILE *f;
char *palette;

 if((f= fopen(filename,"rb")) == NULL)
  err("load_768: fopen()");

 if((palette= (char*)malloc(768)) == NULL)
  err("load_768: malloc()");

 fread(palette,768,1,f);
 fclose(f);
 return(palette);
}


/*
visualizza l'immagine con immagine puntata da image e palette puntata da palette e libera lo spazio
allocato.
L'immagine deve essere del tipo 320*200*256.
*/
void view_64k(char *image, char *palette) {
 int x,y;

 open_pal(palette);
 for(x=0;x<320;x++)
  for(y=0;y<200;y++)
   putpixel(x,y,image[y*320+x]);

  free(image);
  free(palette);

}


