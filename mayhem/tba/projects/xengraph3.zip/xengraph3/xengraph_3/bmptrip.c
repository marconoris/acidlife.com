/*
 *
 * $Id: bmptrip.c,v 2.0 18/05/01 *:*:* xenion Exp $
 *
 * ---------------------------------------------------------------------------
 * No part of this project may be used to break the law, or to cause damage of
 * any kind. And I'm not responsible for anything you do with it.
 * ---------------------------------------------------------------------------
 * "THE BEER-WARE LICENSE" (by Poul-Henning Kamp, Revision 42):
 * <xenion@acidlife.com> wrote this file.  As long as you retain this notice
 * you can do whatever you want with this stuff. If we meet some day, and you
 * think this stuff is worth it, you can buy me a beer in return.
 * xenion ~ Dallachiesa Michele
 * ---------------------------------------------------------------------------
 */

/*

* non testato al 100% *


bmptrip.c

 .bmp viewer & converter (for 13h programmers)

*/

#include "x_graph3.h"
#include "x_bmp3.h"
#include <string.h>

void see_info(BITMAP_HEADER bmp_header) {
 printf("[ bmp_header - (%d bytes)]\n",sizeof bmp_header.file_header);
 printf("bfType           : %u\n",bmp_header.file_header.bfType);
 printf("bfSize           : %lu\n",bmp_header.file_header.bfSize);
 printf("bfReserved1      : %u\n",bmp_header.file_header.bfReserved1);
 printf("bfReserved2      : %u\n",bmp_header.file_header.bfReserved2);
 printf("bfOffBits        : %lu\n",bmp_header.file_header.bfOffBits);
 printf("[ bmp_nfo - (%d bytes)]\n",sizeof bmp_header.info_header);
 printf("biSize           : %lu\n",bmp_header.info_header.biSize);
 printf("biWidth          : %lu\n",bmp_header.info_header.biWidth);
 printf("biHeight         : %lu\n",bmp_header.info_header.biHeight);
 printf("biPlanes         : %u\n",bmp_header.info_header.biPlanes);
 printf("biBitCount       : %u\n",bmp_header.info_header.biBitCount);
 printf("biCompression    : %lu\n",bmp_header.info_header.biCompression);
 printf("biSizeImage      : %lu\n",bmp_header.info_header.biSizeImage);
 printf("biXPelsPerMeter  : %lu\n",bmp_header.info_header.biXPelsPerMeter);
 printf("biYPelsPerMeter  : %lu\n",bmp_header.info_header.biYPelsPerMeter);
 printf("biClrUsed        : %lu\n",bmp_header.info_header.biClrUsed);
 printf("biClrImportant   : %lu\n",bmp_header.info_header.biClrImportant);
}

void help() {
 printf("bmpTrip v2.0 by xenion@acidlife.com\n\n");
 printf(" usage: bmptrip\n\n");
 printf("  -v  x.bmp             view bitmap in MCGA mode\n");
 printf("  -i  x.bmp             view file informations\n");
 printf("  -c x.bmp x.IMM x.PAL  convert bitmap to .IMM(64000bytes) and .PAL(768bytes)\n");
 printf("  -w x.IMM x.PAL        view .IMM @ .PAL\n");
 printf("  -t                    swith to TEXT mode\n");
 printf("  -h                    help\n\n");
}

void free_bmp(BITMAP_DATA bmp_data) {
 free(bmp_data.palette);
 free(bmp_data.image);
}

int main(int argc, char **argv) {
 BITMAP_HEADER bmp_header;
 BITMAP_DATA bmp_data;

 if(argc<2) {
  printf("try bmpTrip -h\n");
  exit(-1);
  }

 if(!strcmp(argv[1],"-v")) {
       if(argc<3)
        err("see -h");
       load_bmp(argv[2], &bmp_header, &bmp_data);
       set_vmode(MCGA);
       open_pal(bmp_data.palette);
       view_bmp(bmp_header, bmp_data.image, 0, 0);
       free_bmp(bmp_data);
       }

 if(!strcmp(argv[1],"-i")) {
       if(argc<3)
        err("see -h");
       load_bmp(argv[2],&bmp_header, &bmp_data);
       see_info(bmp_header);
       free_bmp(bmp_data);
       }

 if(!strcmp(argv[1],"-c")) {
       if(argc<5)
        err("see -h");
       load_bmp(argv[2],&bmp_header, &bmp_data);
       if(WIDTH!=320 || HEIGHT!=200 || bmp_header.info_header.biClrUsed!=256)
        err("with .IMM and .PAL format image must be 320x200x256");
       save_imm(argv[3],bmp_header,bmp_data);
       save_pal(argv[4], bmp_header, bmp_data);
       printf("file %s succesfully converted", argv[2]);
       free_bmp(bmp_data);
       }

 if(!strcmp(argv[1],"-w")) {
       if(argc<4)
        err("see -h");
       set_vmode(MCGA);
       view_64k(load_64k(argv[2]), load_768(argv[3]));
       }

 if(!strcmp(argv[1],"-t"))
       set_vmode(TEXT);

 if(!strcmp(argv[1],"-h"))
       help();

 return(0);
}