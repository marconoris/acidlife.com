xengraph v.3 by xenion aka Dallachiesa Michele

[14/08/01]
corretti alcuni bug, aggiunto lente.c e tolto vgif.c (inutile).

[31/5/2002]
Ho messo i miei header standard comunque nessuna modifica al codice. 
Per quanto mi riguarda e' codice vecchio, poco testato (Solo x_graph3.h 
e' stato testato decentemente) ed e' stato reso pubblico solo per aiutare 
chi volesse giocare con l'int 13h e i .bmp.
NOTE: L'algoritmo per la lente e' stato sviluppato assieme a derte.. 
bye, have fun.